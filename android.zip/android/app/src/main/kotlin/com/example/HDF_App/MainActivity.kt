package com.example.HDF_App

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
